gcc Autorama.c -o Autorama -lglut -lGLU -lGL -lm &
./Autorama
